<head>
<link rel="stylesheet" type="text/css" href="admin_new.css"> 
</head>
<?php

function footer(){

?>
	<p id="footer">
		&copy; 2014 -
		<?php echo date('Y'); ?> Developmental Disabilities Resource Center. All Rights reserved. <br>
		11177 West 8th Avenue, Lakewood, CO 80215  (303)233-3363

	</p>
<?php
}
?>