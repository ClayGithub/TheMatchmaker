<h1>Administrator</h1>
<img src="photo.jpg" width="160" height="70">

<h2>Manage Device</h2>
<ul type="circle" id="list">
	<li><a href="add_device.php">Add Device</a></li>
	<li><a href="add_peripheral.php">Add Peripheral</a></li>
</ul>
