<?php
error_reporting(E_ALL ^ E_NOTICE);
	$db_host = "";
	$db_user = "root";
	$db_password = "password";
	$db_database = "matchmaker";
	
	$config_sitename = "Administration Page";
	$config_basedir = "http://localhost:8080/matchmaker/admin.php";
?>