<head>
<link rel="stylesheet" type="text/css" href="admin_new.css">

</head>

<div id="sbody">

<h3 id="shead">You have succeeded in adding a new peripheral device.</h3>

<p id="select">Would you like to add another device?</p>
<ul id="smenu">
	<li><a href="add_peripheral.php">Yes</a></li>
	<li><a href="admin.php">No</a></li>
</ul>
</div>